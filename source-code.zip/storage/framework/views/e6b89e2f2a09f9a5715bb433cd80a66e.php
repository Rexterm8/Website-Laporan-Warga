<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Notifikasi Laporan</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px;">
  <div style="background-color: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
    <h2 style="color: #333333;">Hallo, <?php echo e($name); ?></h2>
    <p style="color: #555555;">Laporan Anda telah ditindaklanjuti.</p>
    <p style="color: #555555;">Terima kasih telah menggunakan layanan kami.</p>
    <p style="color: #555555;">Salam,</p>
    <p style="color: #555555;">Tim Layanan Pelanggan</p>
  </div>
</body>
</html>
<?php /**PATH D:\Project\Fastwork Project\Laravel\laporan-warga\resources\views/emails/sendemail.blade.php ENDPATH**/ ?>