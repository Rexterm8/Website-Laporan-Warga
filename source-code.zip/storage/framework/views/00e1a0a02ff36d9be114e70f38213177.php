

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-12">
      <!-- Card untuk menampilkan daftar laporan -->
      <div class="card mt-5" data-aos="fade-up" data-aos-delay="800">
         <div class="card-body">
            <!-- Pesan sukses jika ada -->
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissble fade show" role="alert">
               <?php echo e(session('success')); ?>

               <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <!-- Tabel responsif untuk menampilkan daftar laporan -->
            <div class="table-responsive">
               <table class="table">
                  <thead class="text-black">
                     <tr>
                        <th>Nama</th>
                        <th>Tanggal Laporan</th>
                        <th>Isi Laporan</th>
                        <th>Bukti Laporan</th>
                        <th>Status</th>
                        <!-- Kolom tindakan hanya muncul jika pengguna adalah admin -->
                        <?php if(auth()->user()->role == "admin"): ?>
                        <th>Tindakan</th>
                        <?php endif; ?>
                     </tr>
                  </thead>
                  <tbody>
                     <!-- Looping untuk menampilkan setiap laporan -->
                     <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td><?php echo e($row['user']['nama']); ?></td>
                           <td><?php echo e(\Carbon\Carbon::parse($row['created_at'])->format('F d, Y')); ?></td>
                           <td><?php echo e($row['name']); ?></td>
                           <td>
                              <!-- Tombol untuk melihat lampiran laporan -->
                              <a href="<?php echo e(asset($row['lampiran'])); ?>" class="btn btn-primary rounded-pill" target="__blank">Lihat</a>
                           </td>
                           <td>
                              <!-- Menampilkan status laporan -->
                              <?php if($row['status'] == 'Sedang Berjalan'): ?>
                                 <p class="btn btn-warning rounded-pill mt-3"><?php echo e($row['status']); ?></p>
                              <?php elseif($row['status'] == 'Sudah Selesai'): ?>
                                 <p class="btn btn-success rounded-pill mt-3"><?php echo e($row['status']); ?></p>
                              <?php else: ?>
                                 <p class="btn btn-secondary rounded-pill mt-3"><?php echo e($row['status']); ?></p>
                              <?php endif; ?>
                           </td>
                           <!-- Kolom tindakan hanya muncul jika pengguna adalah admin -->
                           <?php if(auth()->user()->role == "admin"): ?>
                           <td>
                               <!-- Tombol untuk mengubah status laporan -->
                              <button type="button" class="btn btn-danger update-status rounded-pill" data-bs-toggle="modal" data-bs-target="#updateStatus" data-id="<?php echo e($row['id']); ?>" <?php if($row['status'] == 'Sudah Selesai'): ?> disabled <?php endif; ?>>
                                 Update Status
                             </button>                          
                           </td>
                           <?php endif; ?>
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                  </tbody>
               </table>
            </div>
         </div>
      </div>
  </div>

  <!-- Modal untuk mengubah status laporan -->
  <div class="modal fade" id="updateStatus" tabindex="-1" aria-labelledby="updateStatusLabel" aria-hidden="true">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <h1 class="modal-title fs-5" id="updateStatusLabel">Modal title</h1>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
               <div class="modal-body text-black">
                     <?php echo method_field('put'); ?>
                     <?php echo csrf_field(); ?>
                     <div class="form-group">
                        <label for="status" class="form-label">Status Laporan</label>
                        <select class="form-control text-black" id="status" name="status" required>
                           <option value="">Pilih Status Laporan</option>                       
                           <option value="Sudah Selesai">Sudah Selesai</option>
                        </select>
                     </div>                 
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-danger">Update Status</button>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
   document.querySelectorAll('.update-status').forEach(button => {
       button.addEventListener('click', function() {
           var laporanId = this.getAttribute('data-id');
           var modalForm = document.querySelector('#updateStatus form');
           modalForm.setAttribute('action', '<?php echo e(route("dashboard.updateStatus", ["laporan" => ":laporan"])); ?>'.replace(':laporan', laporanId));
       });
   });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Fastwork Project\Laravel\laporan-warga\resources\views/dashboard/index.blade.php ENDPATH**/ ?>