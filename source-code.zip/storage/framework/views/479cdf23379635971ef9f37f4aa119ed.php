<footer class="footer">
  <div class="footer-body">
      
  </div>
</footer><?php /**PATH D:\Project\Fastwork Project\Laravel\laporan-warga\resources\views/layouts/footer.blade.php ENDPATH**/ ?>