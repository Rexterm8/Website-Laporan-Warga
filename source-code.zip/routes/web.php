<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HistoryController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Di sini Anda dapat mendaftarkan rute web untuk aplikasi Anda. Semua
| rute ini akan dimuat oleh RouteServiceProvider dan semuanya akan ditugaskan
| ke grup middleware "web". Buatlah sesuatu yang hebat!
|
*/

// Rute untuk halaman utama
Route::get('/', function () {
    return view('homepage');
});

// Rute untuk halaman login
Route::get('/login', [LoginController::class, 'index'])->name('login.index')->middleware('guest');
Route::post('/login', [LoginController::class, 'authenticate'])->name('login.authenticate');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Rute untuk halaman registrasi
Route::get('/register', [RegisterController::class, 'index'])->name('register.index')->middleware('guest');
Route::post('/register', [RegisterController::class, 'store'])->name('register.store');

// Rute untuk halaman dashboard (hanya bisa diakses setelah login)
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index')->middleware('auth');
Route::put('/dashboard/update-status/{laporan}', [DashboardController::class, 'updateStatus'])->name('dashboard.updateStatus')->middleware('auth');

// Rute untuk halaman riwayat laporan (hanya bisa diakses setelah login)
Route::get('/history', [HistoryController::class, 'index'])->name('history.index')->middleware('auth');

// Rute untuk halaman pengelolaan laporan (hanya bisa diakses setelah login)
Route::get('/laporan', [LaporanController::class, 'index'])->name('laporan.index')->middleware('auth');
Route::post('/laporan', [LaporanController::class, 'store'])->name('laporan.store')->middleware('auth');
