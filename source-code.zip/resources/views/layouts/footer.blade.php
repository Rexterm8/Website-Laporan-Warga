<footer class="footer">
  <div class="footer-body">
      
  </div>
</footer>